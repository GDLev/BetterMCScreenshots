package dev.gdlev.better_screenshots.mixin.client;

import dev.gdlev.better_screenshots.client.ScreenshotConfigScreen;
import dev.gdlev.better_screenshots.client.ScreenshotFullscreenScreen;
import dev.gdlev.better_screenshots.client.ScreenshotGalleryScreen;
import dev.gdlev.better_screenshots.client.ScreenshotPreviewRenderer;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseHandlerMixin {

    @Inject(method = "onButton", at = @At("HEAD"), cancellable = true)
    private void onMouseButton(long window, class_11910 input, int action, CallbackInfo ci) {
        if (action != 1) return;

        class_310 mc = class_310.method_1551();
        double mouseX = mc.field_1729.method_1603() / mc.method_22683().method_4495();
        double mouseY = mc.field_1729.method_1604() / mc.method_22683().method_4495();

        // Gallery - Handle thumbnail clicks
        if (mc.field_1755 instanceof ScreenshotGalleryScreen gallery) {
            if (gallery.handleClick(input.comp_4801(), mouseX, mouseY)) {
                ci.cancel();
                return;
            }
        }

        // Configuration - Handle clicks on thumbnails and action buttons
        if (mc.field_1755 instanceof ScreenshotConfigScreen config) {
            if (config.handleClick(input.comp_4801(), mouseX, mouseY)) {
                ci.cancel();
                return;
            }
        }

        // Preview - works when there is no screenshot OR when the screenshot is not a gallery/fullscreen
        if (!(mc.field_1755 instanceof ScreenshotGalleryScreen)
                && !(mc.field_1755 instanceof ScreenshotFullscreenScreen)
                && !(mc.field_1755 instanceof ScreenshotConfigScreen)) {
            if (input.comp_4801() == 0) {
                if (ScreenshotPreviewRenderer.handleClick(mouseX, mouseY)) {
                    ci.cancel();
                }
            }
        }
    }
}