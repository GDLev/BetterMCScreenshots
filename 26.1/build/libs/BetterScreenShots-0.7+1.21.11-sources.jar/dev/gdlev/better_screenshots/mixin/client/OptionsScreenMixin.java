package dev.gdlev.better_screenshots.mixin.client;

import dev.gdlev.better_screenshots.client.ScreenshotConfigScreen;
import dev.gdlev.better_screenshots.client.ScreenshotGalleryScreen;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class OptionsScreenMixin extends class_437 {
    @Unique
    private static final class_2960 ICON_CAMERA    = class_2960.method_60655("better_screenshots", "textures/gui/camera.png");
    @Unique
    private static final class_2960 ICON_GALLERY   = class_2960.method_60655("better_screenshots", "textures/gui/gallery.png");

    @Unique
    private static final int BTN_SIZE = 20;
    @Unique
    private static final int GAP      = 4;

    @Unique
    private class_4185 cameraButton  = null;
    @Unique
    private class_4185 galleryButton = null;

    protected OptionsScreenMixin(class_2561 title) { super(title); }

    @Inject(method = "init", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        int x = 10;
        int y = 10;

        cameraButton = class_4185.method_46430(
                        class_2561.method_43470(""),
                        b -> this.field_22787.method_1507(
                                new ScreenshotConfigScreen(this)))
                .method_46434(x, y, BTN_SIZE, BTN_SIZE)
                .method_46431();

        galleryButton = class_4185.method_46430(
                        class_2561.method_43470(""),
                        b -> this.field_22787.method_1507(
                                new ScreenshotGalleryScreen(this)))
                .method_46434(x + BTN_SIZE + GAP, y, BTN_SIZE, BTN_SIZE)
                .method_46431();

        method_37063(cameraButton);
        method_37063(galleryButton);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, int mouseX, int mouseY,
                          float delta, CallbackInfo ci) {
        drawIcon(context, mouseX, mouseY, cameraButton,  ICON_CAMERA, ICON_CAMERA);
        drawIcon(context, mouseX, mouseY, galleryButton, ICON_GALLERY, ICON_GALLERY);
    }

    @Unique
    private void drawIcon(class_332 context, int mouseX, int mouseY,
                          class_4185 btn, class_2960 icon, class_2960 iconHover) {
        if (btn == null) return;
        boolean hov = mouseX >= btn.method_46426() && mouseX <= btn.method_46426() + BTN_SIZE
                && mouseY >= btn.method_46427() && mouseY <= btn.method_46427() + BTN_SIZE;
        int iconSize = BTN_SIZE - 4;
        int iconX    = btn.method_46426() + 2;
        int iconY    = btn.method_46427() + 2;
        context.method_25290(
                class_10799.field_56883,
                hov ? iconHover : icon,
                iconX, iconY, 0f, 0f,
                iconSize, iconSize, iconSize, iconSize);
    }
}