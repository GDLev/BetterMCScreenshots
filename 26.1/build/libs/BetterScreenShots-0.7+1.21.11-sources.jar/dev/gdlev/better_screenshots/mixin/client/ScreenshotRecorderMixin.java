package dev.gdlev.better_screenshots.mixin.client;

import dev.gdlev.better_screenshots.client.Better_screenshotsClient;
import dev.gdlev.better_screenshots.client.ScreenshotConfig;
import dev.gdlev.better_screenshots.client.ScreenshotPreviewRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;
import java.util.function.Consumer;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_5250;

@Mixin(class_318.class)
public class ScreenshotRecorderMixin {
    @Unique
    private static boolean suppressNext = false;

    @Inject(method = "grab*", at = @At("HEAD"), cancellable = true)
    private static void onSaveScreenshot(
            File gameDirectory,
            class_276 framebuffer,
            Consumer<class_2561> messageReceiver,
            CallbackInfo ci
    ) {
        if (suppressNext) {
            suppressNext = false;
            return;
        }

        if (framebuffer == null) return;

        class_310 client = class_310.method_1551();
        ScreenshotConfig cfg   = ScreenshotConfig.get();

        suppressNext = true;
        class_318.method_1659(gameDirectory, framebuffer, msg -> {});

        final boolean fullscreenOpen = client.field_1755 instanceof dev.gdlev.better_screenshots.client.ScreenshotFullscreenScreen;
        final String screenshotId = String.valueOf(System.nanoTime());

        class_318.method_1663(framebuffer, image -> {
            if (!fullscreenOpen) {
                ScreenshotPreviewRenderer.setPreview(image);
            }

            client.execute(() -> {
                File screenshotsDir = new File(client.field_1697, "screenshots");
                File[] files = screenshotsDir.listFiles(
                        f -> f.isFile() && f.getName().toLowerCase().endsWith(".png"));
                String fileName = class_2561.method_43471(
                        "better_screenshots.chat.default_filename").getString();
                File screenshotFile = null;
                if (files != null && files.length > 0) {
                    java.util.Arrays.sort(files,
                            java.util.Comparator.comparingLong(File::lastModified).reversed());
                    screenshotFile = files[0];
                    fileName = screenshotFile.getName();
                }

                if (screenshotFile != null) {
                    ScreenshotPreviewRenderer.registerFile(screenshotId, screenshotFile);
                }

                final String finalFileName = fileName;

                class_5250 prefix = class_2561.method_43470("").method_27692(class_124.field_1080);

                class_5250 fileLink = class_2561.method_43470(finalFileName)
                        .method_27694(s -> s
                                .method_30938(true)
                                .method_10977(class_124.field_1080)
                                .method_10949(new class_2568.class_10613(
                                        class_2561.method_43471("better_screenshots.chat.open_folder_hint")
                                                .method_27692(class_124.field_1063)))
                                .method_10958(new class_2558.class_10607(
                                        new File(client.field_1697, "screenshots")
                                                .getAbsolutePath())));

                class_5250 sep = class_2561.method_43470("  ").method_27692(class_124.field_1063);

                class_5250 previewBtn = class_2561.method_43470("[")
                        .method_27692(class_124.field_1063)
                        .method_10852(class_2561.method_43471("better_screenshots.chat.preview")
                                .method_27694(s -> s
                                        .method_10977(class_124.field_1054)
                                        .method_10982(false)
                                        .method_10949(new class_2568.class_10613(
                                                class_2561.method_43471("better_screenshots.chat.preview_hint")
                                                        .method_27692(class_124.field_1063)))
                                        .method_10958(new class_2558.class_10609(
                                                "/better_screenshots preview " + screenshotId))))
                        .method_10852(class_2561.method_43470("]").method_27692(class_124.field_1063));

                class_5250 sep2 = class_2561.method_43470(" ").method_27692(class_124.field_1063);

                class_5250 copyBtn = class_2561.method_43470("[")
                        .method_27692(class_124.field_1063)
                        .method_10852(class_2561.method_43471("better_screenshots.chat.copy")
                                .method_27694(s -> s
                                        .method_10977(class_124.field_1060)
                                        .method_10982(false)
                                        .method_10949(new class_2568.class_10613(
                                                class_2561.method_43471("better_screenshots.chat.copy_hint")
                                                        .method_27692(class_124.field_1063)))
                                        .method_10958(new class_2558.class_10609(
                                                "/better_screenshots copy " + screenshotId))))
                        .method_10852(class_2561.method_43470("]").method_27692(class_124.field_1063));

                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            prefix.method_10852(fileLink).method_10852(sep)
                                    .method_10852(previewBtn).method_10852(sep2).method_10852(copyBtn),
                            false);
                }
            });

            client.execute(() -> {
                if (cfg.shutterSound == ScreenshotConfig.ShutterSound.NONE) return;
                net.minecraft.class_3414 sound = switch (cfg.shutterSound) {
                    case SOFT    -> Better_screenshotsClient.SHUTTER_SOFT;
                    case CLASSIC -> Better_screenshotsClient.SHUTTER_CLASSIC;
                    default      -> null;
                };
                if (sound != null)
                    client.method_1483().method_4873(
                            class_1109.method_4758(sound, 1.0f));
            });
        });

        ci.cancel(); // cancel the original call (which would have displayed the default message)
    }
}