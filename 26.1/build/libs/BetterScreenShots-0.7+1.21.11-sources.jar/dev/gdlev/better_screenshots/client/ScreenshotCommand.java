package dev.gdlev.better_screenshots.client;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_310;

public class ScreenshotCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {

        dispatcher.register(
                ClientCommandManager.literal("better_screenshots")
                        .then(ClientCommandManager.literal("preview")
                                .then(ClientCommandManager.argument("id", StringArgumentType.word())
                                        .executes(ctx -> {
                                            String id = StringArgumentType.getString(ctx, "id");
                                            class_310 mc = class_310.method_1551();
                                            mc.execute(() -> {
                                                ScreenshotFullscreenScreen screen =
                                                        new ScreenshotFullscreenScreen(mc.field_1755);
                                                mc.method_1507(screen);
                                                ScreenshotPreviewRenderer.loadAndPreview(id, screen);
                                            });
                                            return 1;
                                        }))
                                .executes(ctx -> {
                                    class_310 mc = class_310.method_1551();
                                    mc.execute(() -> {
                                        if (ScreenshotPreviewRenderer.getPreviewTexture() != null) {
                                            ScreenshotFullscreenScreen screen =
                                                    new ScreenshotFullscreenScreen(mc.field_1755);
                                            screen.useCurrentTexture();
                                            mc.method_1507(screen);
                                        }
                                    });
                                    return 1;
                                }))
                        .then(ClientCommandManager.literal("copy")
                                .then(ClientCommandManager.argument("id", StringArgumentType.word())
                                        .executes(ctx -> {
                                            String id = StringArgumentType.getString(ctx, "id");
                                            class_310 mc = class_310.method_1551();
                                            mc.execute(() -> ScreenshotPreviewRenderer.copyFile(id));
                                            return 1;
                                        }))
                                .executes(ctx -> {
                                    class_310 mc = class_310.method_1551();
                                    mc.execute(() -> {
                                        try {
                                            java.lang.reflect.Method m =
                                                    ScreenshotPreviewRenderer.class
                                                            .getDeclaredMethod("copyToClipboard");
                                            m.setAccessible(true);
                                            m.invoke(null);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    });
                                    return 1;
                                }))
        );
    }
}