package dev.gdlev.better_screenshots.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3414;
import net.minecraft.class_3675;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

public class Better_screenshotsClient implements ClientModInitializer {

    public static final class_2960 SHUTTER_SOFT_ID    = class_2960.method_60655("better_screenshots", "shutter_soft");
    public static final class_2960 SHUTTER_CLASSIC_ID = class_2960.method_60655("better_screenshots", "shutter_classic");
    public static class_3414 SHUTTER_SOFT;
    public static class_3414 SHUTTER_CLASSIC;

    private static class_304 openConfigKey;

    @Override
    public void onInitializeClient() {
        ScreenshotConfig.load();

        // Sound mapping
        SHUTTER_SOFT    = class_2378.method_10230(class_7923.field_41172, SHUTTER_SOFT_ID,    class_3414.method_47908(SHUTTER_SOFT_ID));
        SHUTTER_CLASSIC = class_2378.method_10230(class_7923.field_41172, SHUTTER_CLASSIC_ID, class_3414.method_47908(SHUTTER_CLASSIC_ID));

        // Keybind mapping
        openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.better_screenshots.open_config",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F8,
                new class_304.class_11900(class_2960.method_60654("category.better_screenshots"))
        ));

        // Keybinds
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openConfigKey.method_1436()) {
                client.method_1507(new ScreenshotConfigScreen(client.field_1755));
            }
        });

        // Connecting the renderer to the HUD
        HudRenderCallback.EVENT.register((context, tickDelta) -> ScreenshotPreviewRenderer.render(context));

        // Command mapping
        net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback.EVENT
                .register((dispatcher, registryAccess) ->
                        ScreenshotCommand.register(dispatcher));
    }
}