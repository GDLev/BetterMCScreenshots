package dev.gdlev.better_screenshots.client;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ScreenshotGalleryScreen extends class_437 {

    private final class_437 parent;

    private static final int COLS       = 4;
    private static final int THUMB_W    = 80;
    private static final int THUMB_H    = 45;
    private static final int THUMB_GAP  = 6;
    private static final int TOP_PAD    = 30;
    private static final int BOTTOM_PAD = 36;

    private final List<File>                     files         = new ArrayList<>();
    private final List<class_2960>               thumbIds      = new ArrayList<>();
    private final List<class_1043> thumbTextures = new ArrayList<>();

    private int   scrollOffset   = 0;
    private int   totalContentH  = 0;
    private int   selectedIdx    = -1;

    private final int[] actionBtnX = new int[3];
    private final int[] actionBtnY = new int[3];
    private static final int ACT_BTN_W = 8;
    private static final int ACT_BTN_H = 10;
    private static final int ACT_BTN_GAP = 0;

    private static final class_2960 ICON_SHOW    = class_2960.method_60655("better_screenshots", "textures/gui/show.png");
    private static final class_2960 ICON_SHOW_H  = class_2960.method_60655("better_screenshots", "textures/gui/show_hover.png");
    private static final class_2960 ICON_COPY    = class_2960.method_60655("better_screenshots", "textures/gui/copy.png");
    private static final class_2960 ICON_COPY_H  = class_2960.method_60655("better_screenshots", "textures/gui/copy_hover.png");
    private static final class_2960 ICON_DELETE  = class_2960.method_60655("better_screenshots", "textures/gui/close.png");
    private static final class_2960 ICON_DELETE_H= class_2960.method_60655("better_screenshots", "textures/gui/close_hover.png");

    private float marqueeOffset    = 0f;
    private long  marqueeLastMs    = -1;
    private int   marqueeIdx       = -1;
    private int   marqueePauseTimer = 60;
    private static final float MARQUEE_SPEED = 30f;
    private static final int   MARQUEE_PAUSE = 60;

    public ScreenshotGalleryScreen(class_437 parent) {
        super(class_2561.method_43471("better_screenshots.gallery.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        method_37063(class_4185.method_46430(
                        class_2561.method_43471("better_screenshots.gallery.back"),
                        btn -> field_22787.method_1507(parent))
                .method_46434(8, 4, 60, 14)
                .method_46431());

        if (files.isEmpty() && thumbIds.isEmpty()) {
            loadScreenshots();
        }
    }

    private static final int MAX_CONCURRENT_LOADS = 4;
    private final java.util.concurrent.Semaphore loadSemaphore =
            new java.util.concurrent.Semaphore(MAX_CONCURRENT_LOADS);

    private void loadScreenshots() {
        for (class_1043 t : thumbTextures) if (t != null) t.close();
        thumbTextures.clear();
        thumbIds.clear();
        files.clear();
        selectedIdx  = -1;
        scrollOffset = 0;

        class_310 mc = class_310.method_1551();
        File dir = new File(mc.field_1697, "screenshots");
        if (!dir.exists()) return;

        File[] found = dir.listFiles(
                f -> f.isFile() && f.getName().toLowerCase().endsWith(".png"));
        if (found == null) return;

        Arrays.sort(found, Comparator.comparingLong(File::lastModified).reversed());
        Collections.addAll(files, found);

        for (int i = 0; i < files.size(); i++) {
            thumbIds.add(class_2960.method_60655("better_screenshots",
                    "gal_thumb_" + i + "_" + files.get(i).lastModified()));
            thumbTextures.add(null);
        }

        int priority = Math.min(files.size(), 8);
        for (int i = 0; i < priority; i++) {
            final int idx = i;
            Thread.ofVirtual().start(() -> loadThumbLimited(mc, idx));
        }
        for (int i = priority; i < files.size(); i++) {
            final int idx = i;
            Thread.ofVirtual().start(() -> {
                try { Thread.sleep(idx * 5L); } catch (Exception ignored) {}
                loadThumbLimited(mc, idx);
            });
        }

        recalcContentH();
        refreshActionButtons();
    }

    private void loadThumbLimited(class_310 mc, int idx) {
        try {
            loadSemaphore.acquire();
            loadThumb(mc, idx);
        } catch (InterruptedException ignored) {
        } finally {
            loadSemaphore.release();
        }
    }
    private void recalcContentH() {
        int rows = (int) Math.ceil((double) files.size() / COLS);
        totalContentH = rows * (THUMB_H + THUMB_GAP);
    }

    private void loadThumb(class_310 mc, int idx) {
        try (InputStream is = Files.newInputStream(files.get(idx).toPath())) {
            class_1011 img   = class_1011.method_4309(is);
            class_1011 thumb = scaleTo(img);
            img.close();
            mc.execute(() -> {
                if (idx >= thumbTextures.size()) return;
                class_1043 tex =
                        new class_1043(() -> "gal_" + idx, thumb);
                mc.method_1531().method_4616(thumbIds.get(idx), tex);
                thumbTextures.set(idx, tex);
            });
        } catch (Exception ignored) {}
    }

    private class_1011 scaleTo(class_1011 src) {
        float scale = Math.min((float) ScreenshotGalleryScreen.THUMB_W / src.method_4307(),
                (float) ScreenshotGalleryScreen.THUMB_H / src.method_4323());
        int sw = Math.max(1, (int)(src.method_4307()  * scale));
        int sh = Math.max(1, (int)(src.method_4323() * scale));
        int ox = (ScreenshotGalleryScreen.THUMB_W - sw) / 2;
        int oy = (ScreenshotGalleryScreen.THUMB_H - sh) / 2;

        float scaleX = (float) src.method_4307()  / sw;
        float scaleY = (float) src.method_4323() / sh;

        class_1011 dst = new class_1011(ScreenshotGalleryScreen.THUMB_W, ScreenshotGalleryScreen.THUMB_H, false);

        for (int y = 0; y < ScreenshotGalleryScreen.THUMB_H; y++)
            for (int x = 0; x < ScreenshotGalleryScreen.THUMB_W; x++)
                dst.method_4305(x, y, 0xFF000000);

        for (int y = 0; y < sh; y++) {
            int sy = Math.min((int)(y * scaleY), src.method_4323() - 1);
            for (int x = 0; x < sw; x++) {
                int sx   = Math.min((int)(x * scaleX), src.method_4307() - 1);
                int argb = src.method_61940(sx, sy);
                int a    = (argb >> 24) & 0xFF;
                int r    = (argb >> 16) & 0xFF;
                int g    = (argb >>  8) & 0xFF;
                int b    =  argb        & 0xFF;
                dst.method_4305(ox + x, oy + y, (a << 24) | (b << 16) | (g << 8) | r);
            }
        }
        return dst;
    }

    // Layout

    private int gridW()      { return COLS * THUMB_W + (COLS - 1) * THUMB_GAP; }
    private int gridStartX() { return (this.field_22789 - gridW()) / 2; }
    private int gridBottomY(){ return this.field_22790 - BOTTOM_PAD; }

    // Click handling

    public boolean handleClick(int button, double mouseX, double mouseY) {
        if (button != 0) return false;

        if (selectedIdx >= 0) {
            for (int i = 0; i < 3; i++) {
                if (mouseX >= actionBtnX[i] && mouseX <= actionBtnX[i] + ACT_BTN_W
                        && mouseY >= actionBtnY[i] && mouseY <= actionBtnY[i] + ACT_BTN_H) {
                    switch (i) {
                        case 0 -> openFullscreen(selectedIdx);
                        case 1 -> copyFile(selectedIdx);
                        case 2 -> deleteFile(selectedIdx);
                    }
                    return true;
                }
            }
        }

        int sx      = gridStartX();
        int bottomY = gridBottomY();

        for (int i = 0; i < files.size(); i++) {
            int col = i % COLS;
            int row = i / COLS;
            int x   = sx + col * (THUMB_W + THUMB_GAP);
            int y = TOP_PAD + row * (THUMB_H + THUMB_GAP) - scrollOffset;

            if (mouseX >= x && mouseX <= x + THUMB_W
                    && mouseY >= y && mouseY <= y + THUMB_H
                    && mouseY >= TOP_PAD && mouseY <= bottomY) {
                selectedIdx = (selectedIdx == i) ? -1 : i;
                marqueeIdx  = -1;
                refreshActionButtons();
                return true;
            }
        }
        return false;
    }

    // Render

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF111111);

        context.method_27534(field_22793,
                field_22785, this.field_22789 / 2, 6, 0xFFFFFF);

        int sx      = gridStartX();
        int bottomY = gridBottomY();

        // Scissor net
        context.method_44379(0, TOP_PAD - 2, this.field_22789, bottomY);

        for (int i = 0; i < files.size(); i++) {
            int col = i % COLS;
            int row = i / COLS;
            int x   = sx + col * (THUMB_W + THUMB_GAP);
            int y   = TOP_PAD + row * (THUMB_H + THUMB_GAP) - scrollOffset;

            if (y + THUMB_H < TOP_PAD || y > bottomY) continue;

            boolean hov = mouseX >= x && mouseX <= x + THUMB_W
                    && mouseY >= y && mouseY <= y + THUMB_H
                    && mouseY >= TOP_PAD && mouseY <= bottomY;
            boolean sel = (i == selectedIdx);

            int border = sel ? 0xFFFFFFFF : hov ? 0xFFAAAAAA : 0xFF555555;
            context.method_25294(x - 1, y - 1, x + THUMB_W + 1, y + THUMB_H + 1, border);

            if (i < thumbTextures.size() && thumbTextures.get(i) != null) {
                context.method_25290(
                        class_10799.field_56883, thumbIds.get(i),
                        x, y, 0f, 0f, THUMB_W, THUMB_H, THUMB_W, THUMB_H);
            } else {
                context.method_25294(x, y, x + THUMB_W, y + THUMB_H, 0xFF2a2a2a);
                context.method_27534(field_22793,
                        class_2561.method_43471("better_screenshots.gallery.loading"),
                        x + THUMB_W / 2, y + THUMB_H / 2 - 4, 0xFF555555);
            }

            // Copy animation
            if (sel) {
                int ca = ScreenshotPreviewRenderer.getCopyFlashAlpha();
                if (ca > 0) context.method_25294(x, y, x + THUMB_W, y + THUMB_H, (ca << 24) | 0x004499FF);
            }

            // Name display on hover
            if (hov && y >= TOP_PAD && y + THUMB_H <= bottomY) {
                context.method_44380();
                context.method_44379(x, y, x + THUMB_W, y + THUMB_H);

                String name = files.get(i).getName().replace(".png", "");
                int nameW   = field_22793.method_1727(name);
                int labelH  = 12;
                int labelY  = y + THUMB_H - labelH;

                context.method_25294(x, labelY, x + THUMB_W, y + THUMB_H, 0xCC000000);

                if (nameW <= THUMB_W - 4) {
                    context.method_27534(field_22793,
                            class_2561.method_43470(name), x + THUMB_W / 2, labelY + 2, 0xFFFFFFFF);
                } else {
                    String clipped = name;
                    while (field_22793.method_1727(clipped + "…") > THUMB_W - 4
                            && !clipped.isEmpty()) {
                        clipped = clipped.substring(0, clipped.length() - 1);
                    }
                    context.method_27534(field_22793,
                            class_2561.method_43470(clipped + "…"), x + THUMB_W / 2, labelY + 2, 0xFFFFFFFF);
                }

                context.method_44380();
                context.method_44379(0, TOP_PAD, this.field_22789, bottomY);
            }
        }

        context.method_44380();

        // Info panel
        if (selectedIdx >= 0 && selectedIdx < files.size()) {
            drawSelectedPanel(context);
        } else {
            context.method_27534(field_22793,
                    class_2561.method_43471("better_screenshots.gallery.tip"),
                    this.field_22789 / 2, this.field_22790 - BOTTOM_PAD + 12, 0xFF555555);
        }

        // Scrollbar
        int visibleH = bottomY - TOP_PAD;
        if (totalContentH > visibleH) {
            int tmbH   = Math.max(16, visibleH * visibleH / totalContentH);
            int maxSc  = totalContentH - visibleH;
            int tmbY   = TOP_PAD + (maxSc > 0
                    ? (int)((float) scrollOffset / maxSc * (visibleH - tmbH)) : 0);
            int tx     = this.field_22789 - 5;
            context.method_25294(tx, TOP_PAD, tx + 3, TOP_PAD + visibleH, 0x33FFFFFF);
            context.method_25294(tx, tmbY,    tx + 3, tmbY + tmbH,      0xBBFFFFFF);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawSelectedPanel(class_332 context) {
        if (selectedIdx < 0 || selectedIdx >= files.size()) return;

        int col    = selectedIdx % COLS;
        int row    = selectedIdx / COLS;
        int sx     = gridStartX();
        int thumbX = sx + col * (THUMB_W + THUMB_GAP);
        int thumbY = TOP_PAD + row * (THUMB_H + THUMB_GAP) - scrollOffset;

        boolean thumbVisible = thumbY + THUMB_H > TOP_PAD && thumbY < gridBottomY();

        if (thumbVisible) {
            // Action buttons
            int totalBtnsW = 3 * ACT_BTN_W + 2 * ACT_BTN_GAP;
            int btnsStartX = thumbX + THUMB_W - totalBtnsW - 2;
            int btnsY      = thumbY + 2;

            class_310 mc = class_310.method_1551();
            double mouseX = mc.field_1729.method_1603() / mc.method_22683().method_4495();
            double mouseY = mc.field_1729.method_1604() / mc.method_22683().method_4495();

            class_2960[] icons = {ICON_SHOW, ICON_COPY, ICON_DELETE};
            class_2960[] iconsH = {ICON_SHOW_H, ICON_COPY_H, ICON_DELETE_H};

            for (int i = 0; i < 3; i++) {
                actionBtnX[i] = btnsStartX + i * (ACT_BTN_W + ACT_BTN_GAP);
                actionBtnY[i] = btnsY;

                boolean hov = mouseX >= actionBtnX[i]
                        && mouseX <= actionBtnX[i] + ACT_BTN_W
                        && mouseY >= actionBtnY[i]
                        && mouseY <= actionBtnY[i] + ACT_BTN_H;

                context.method_25290(
                        class_10799.field_56883,
                        hov ? iconsH[i] : icons[i],
                        actionBtnX[i], actionBtnY[i],
                        0f, 0f, ACT_BTN_W, ACT_BTN_H, ACT_BTN_W, ACT_BTN_H);
            }
        } else {
            for (int i = 0; i < 3; i++) {
                actionBtnX[i] = -100;
                actionBtnY[i] = -100;
            }
        }

        // File name info
        String fullName  = files.get(selectedIdx).getName().replace(".png", "");
        int    panelY    = this.field_22790 - BOTTOM_PAD;
        int    textAreaW = 220;
        int    textX     = this.field_22789 / 2 - textAreaW / 2;
        int    textY     = panelY + 5;
        int    fullW     = field_22793.method_1727(fullName);

        context.method_25294(0, panelY, this.field_22789, panelY + BOTTOM_PAD, 0xCC000000);
        context.method_25294(0, panelY, this.field_22789, panelY + 1,          0xFF444444);

        if (fullW <= textAreaW) {
            marqueeOffset     = 0;
            marqueePauseTimer = MARQUEE_PAUSE;
            context.method_27534(field_22793,
                    class_2561.method_43470(fullName), this.field_22789 / 2, textY, 0xFFCCCCCC);
        } else {
            if (marqueeIdx != selectedIdx) {
                marqueeIdx        = selectedIdx;
                marqueeOffset     = 0f;
                marqueePauseTimer = MARQUEE_PAUSE;
                marqueeLastMs     = System.currentTimeMillis();
            }

            long  now  = System.currentTimeMillis();
            float dtMs = marqueeLastMs < 0 ? 0 : (now - marqueeLastMs);
            marqueeLastMs = now;

            if (marqueePauseTimer > 0) {
                marqueePauseTimer--;
            } else {
                marqueeOffset += MARQUEE_SPEED * (dtMs / 1000f);
                if (marqueeOffset > fullW - textAreaW + 10) {
                    marqueeOffset     = 0f;
                    marqueePauseTimer = MARQUEE_PAUSE;
                }
            }

            context.method_44379(textX, textY - 1, textX + textAreaW, textY + 10);
            context.method_27535(field_22793,
                    class_2561.method_43470(fullName),
                    textX - (int) marqueeOffset, textY, 0xFFCCCCCC);
            context.method_44380();

            context.method_25294(textX,                  textY - 1, textX + 12,        textY + 10, 0xDD000000);
            context.method_25294(textX + textAreaW - 12, textY - 1, textX + textAreaW, textY + 10, 0xDD000000);
        }
    }


    private void openFullscreen(int idx) {
        class_310 mc = class_310.method_1551();
        ScreenshotFullscreenScreen screen = new ScreenshotFullscreenScreen(this);

        mc.method_1507(screen);

        Thread.ofVirtual().start(() -> {
            try {
                byte[] bytes = Files.readAllBytes(files.get(idx).toPath());
                class_1011 img = class_1011.method_4309(new java.io.ByteArrayInputStream(bytes));
                mc.execute(() -> {
                    ScreenshotPreviewRenderer.setFullscreenTexture(img);
                    screen.markLoaded();
                });
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void refreshActionButtons() {
        method_37067();
        method_37063(class_4185.method_46430(
                        class_2561.method_43471("better_screenshots.gallery.back"),
                        btn -> field_22787.method_1507(parent))
                .method_46434(8, 4, 60, 14)
                .method_46431());
    }

    private void copyFile(int idx) {
        if (idx < 0 || idx >= files.size()) return;
        ScreenshotPreviewRenderer.copyFileToClipboard(files.get(idx));
    }

    private void deleteFile(int idx) {
        File file = files.get(idx);
        if (file.delete()) {
            if (idx < thumbTextures.size()) {
                class_1043 t = thumbTextures.get(idx);
                if (t != null) t.close();
            }
            files.remove(idx);
            thumbIds.remove(idx);
            thumbTextures.remove(idx);
            recalcContentH();
            selectedIdx = -1;
            refreshActionButtons();
        }
    }

    public boolean method_25401(double mx, double my,
                                 double hAmount, double vAmount) {
        int visibleH  = gridBottomY() - TOP_PAD;
        int maxScroll = Math.max(0, totalContentH - visibleH);
        scrollOffset  = Math.max(0, Math.min(
                scrollOffset - (int)(vAmount * 20), maxScroll));
        return true;
    }

    @Override
    public void method_25419() {
        for (class_1043 t : thumbTextures) if (t != null) t.close();
        field_22787.method_1507(parent);
    }
}