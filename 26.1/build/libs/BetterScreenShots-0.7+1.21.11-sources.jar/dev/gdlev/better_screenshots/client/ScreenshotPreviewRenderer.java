package dev.gdlev.better_screenshots.client;

import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ScreenshotPreviewRenderer {

    private static class_1043 previewTexture;
    public static final class_2960 PREVIEW_ID =
            class_2960.method_60655("better_screenshots", "screenshot_preview");

    private static class_1043 fullscreenTexture;
    public static final class_2960 FULLSCREEN_ID =
            class_2960.method_60655("better_screenshots", "screenshot_fullscreen");

    public static class_1043 getFullscreenTexture() { return fullscreenTexture; }

    private static class_1043 backgroundTexture;
    public static final class_2960 BACKGROUND_ID =
            class_2960.method_60655("better_screenshots", "screenshot_background");

    public static void captureBackground(Runnable onReady) {
        class_310 mc = class_310.method_1551();
        net.minecraft.class_318.method_1663(mc.method_1522(), image -> mc.execute(() -> {
            if (backgroundTexture != null) backgroundTexture.close();
            backgroundTexture = new class_1043(() -> "screenshot_background", image);
            mc.method_1531().method_4616(BACKGROUND_ID, backgroundTexture);
            if (onReady != null) onReady.run();
        }));
    }

    public static void setFullscreenTexture(class_1011 image) {
        class_310 mc = class_310.method_1551();
        if (fullscreenTexture != null) fullscreenTexture.close();
        fullscreenTexture = new class_1043(() -> "screenshot_fullscreen", image);
        mc.method_1531().method_4616(FULLSCREEN_ID, fullscreenTexture);
    }

    private static long showUntil      = -1;
    private static long showFrom       = -1;
    private static long flashStart     = -1;
    private static long copyFlashStart = -1;
    private static long closeStart     = -1;

    private static final long  FLASH_DURATION_MS = 400;
    private static final long  COPY_FLASH_MS     = 350;
    private static final long  ENTER_DURATION_MS = 300;
    private static final long  EXIT_DURATION_MS  = 500;
    private static final long  CLOSE_DURATION_MS = 300;
    private static final long  BOUNCE_UP_MS      = 150;
    private static final float BOUNCE_HEIGHT     = 18f;
    private static final float EXIT_DROP         = 120f;

    private static final int BTN_W   = 8;
    private static final int BTN_H   = 10;
    private static final int BTN_GAP = 0;

    private static final class_2960 ICON_SHOW    = class_2960.method_60655("better_screenshots", "textures/gui/show.png");
    private static final class_2960 ICON_SHOW_H  = class_2960.method_60655("better_screenshots", "textures/gui/show_hover.png");
    private static final class_2960 ICON_COPY    = class_2960.method_60655("better_screenshots", "textures/gui/copy.png");
    private static final class_2960 ICON_COPY_H  = class_2960.method_60655("better_screenshots", "textures/gui/copy_hover.png");
    private static final class_2960 ICON_CLOSE   = class_2960.method_60655("better_screenshots", "textures/gui/close.png");
    private static final class_2960 ICON_CLOSE_H = class_2960.method_60655("better_screenshots", "textures/gui/close_hover.png");

    private static int       hoveredButton = -1;
    private static final int[] btnX        = new int[3];
    private static final int[] btnY        = new int[3];

    public static class_1043 getPreviewTexture() { return previewTexture; }

    private static final java.util.concurrent.ConcurrentHashMap<String, java.io.File> pendingFiles
            = new java.util.concurrent.ConcurrentHashMap<>();

    public static void registerFile(String id, java.io.File file) {
        pendingFiles.put(id, file);
    }

    public static void loadAndPreview(String id, ScreenshotFullscreenScreen screen) {
        java.io.File file = pendingFiles.get(id);
        if (file == null || !file.exists()) return;
        class_310 mc = class_310.method_1551();
        Thread.ofVirtual().start(() -> {
            try {
                byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
                class_1011 img = class_1011.method_4309(new java.io.ByteArrayInputStream(bytes));
                mc.execute(() -> {
                    if (fullscreenTexture != null) fullscreenTexture.close();
                    fullscreenTexture = new class_1043(() -> "screenshot_fullscreen", img);
                    mc.method_1531().method_4616(FULLSCREEN_ID, fullscreenTexture);
                    screen.markLoaded();
                });
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    public static void copyFile(String id) {
        java.io.File file = pendingFiles.get(id);
        if (file == null || !file.exists()) return;
        copyFileToClipboard(file);
    }

    public static void copyFileToClipboard(java.io.File file) {
        if (file == null || !file.exists()) return;
        class_310 mc = class_310.method_1551();
        Thread.ofVirtual().start(() -> {
            try {
                byte[] bytes = java.nio.file.Files.readAllBytes(file.toPath());
                class_1011 img = class_1011.method_4309(new java.io.ByteArrayInputStream(bytes));
                mc.execute(() -> {
                    try {
                        java.io.File tmp = java.io.File.createTempFile("better_screenshots_", ".png");
                        tmp.deleteOnExit();
                        img.method_4314(tmp.toPath());
                        copyPathToClipboard(tmp.getAbsolutePath());
                    } catch (Exception e) { e.printStackTrace(); }
                    img.close();
                });
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    public static int getCopyFlashAlpha() {
        if (copyFlashStart < 0) return 0;
        long ce = System.currentTimeMillis() - copyFlashStart;
        if (ce >= COPY_FLASH_MS) { copyFlashStart = -1; return 0; }
        return (int)((1f - (float) ce / COPY_FLASH_MS) * 110);
    }


    public static void setPreview(class_1011 image) {
        if (previewTexture != null) previewTexture.close();
        previewTexture = new class_1043(() -> "screenshot_preview", image);
        class_310.method_1551().method_1531()
                .method_4616(PREVIEW_ID, previewTexture);
        showFrom       = System.currentTimeMillis();
        showUntil      = showFrom + (ScreenshotConfig.get().previewDurationSeconds * 1000L);
        flashStart     = ScreenshotConfig.get().animations ? showFrom : -1;
        closeStart     = -1;
        copyFlashStart = -1;
        hoveredButton  = -1;
    }

    public static void close() {
        if (closeStart == -1) closeStart = System.currentTimeMillis();
    }

    private static float easeOutCubic(float t) { return 1f - (float) Math.pow(1f - t, 3); }
    private static float easeInCubic(float t)  { return t * t * t; }
    private static float easeOutQuad(float t)  { return 1f - (1f - t) * (1f - t); }

    public static void render(class_332 context) {
        long now = System.currentTimeMillis();
        if (showFrom == -1) return;
        if (previewTexture == null || previewTexture.method_4525() == null) return;

        class_310 mc = class_310.method_1551();
        ScreenshotConfig cfg = ScreenshotConfig.get();

        int screenW    = context.method_51421();
        int screenH    = context.method_51443();
        int baseWidth  = screenW / 4;
        int baseHeight = (baseWidth * previewTexture.method_4525().method_4323())
                / previewTexture.method_4525().method_4307();
        int margin     = 10;

        int baseX = switch (cfg.corner) {
            case BOTTOM_RIGHT, TOP_RIGHT -> screenW - baseWidth - margin;
            case BOTTOM_LEFT,  TOP_LEFT  -> margin;
        };
        int baseY = switch (cfg.corner) {
            case BOTTOM_RIGHT, BOTTOM_LEFT -> screenH - baseHeight - margin;
            case TOP_RIGHT,    TOP_LEFT    -> margin;
        };

        float alpha   = 1f;
        float scale   = 1f;
        float offsetY = 0f;
        float offsetX = 0f;

        long elapsed   = now - showFrom;
        long remaining = showUntil - now;

        if (closeStart != -1) {
            long ce = now - closeStart;
            if (!cfg.animations || ce > CLOSE_DURATION_MS) {
                showUntil = -1; showFrom = -1; closeStart = -1;
                flashStart = -1; copyFlashStart = -1;
                return;
            }
            float t    = easeInCubic((float) ce / CLOSE_DURATION_MS);
            float dir  = switch (cfg.corner) {
                case BOTTOM_RIGHT, TOP_RIGHT ->  1f;
                case BOTTOM_LEFT,  TOP_LEFT  -> -1f;
            };
            offsetX = dir * (baseWidth + margin + 10) * t;
            alpha   = 1f - easeOutQuad(t);

        } else if (remaining <= 0) {
            long exitElapsed = now - showUntil;
            if (exitElapsed > EXIT_DURATION_MS) {
                showUntil = -1; showFrom = -1; flashStart = -1;
                return;
            }
            if (cfg.animations) {
                float dropDir = switch (cfg.corner) {
                    case TOP_RIGHT,    TOP_LEFT     -> -1f;
                    case BOTTOM_RIGHT, BOTTOM_LEFT  ->  1f;
                };
                if (exitElapsed < BOUNCE_UP_MS) {
                    float t = (float) exitElapsed / BOUNCE_UP_MS;
                    offsetY = -dropDir * BOUNCE_HEIGHT * easeOutCubic(t);
                } else {
                    float t = (float)(exitElapsed - BOUNCE_UP_MS)
                            / (EXIT_DURATION_MS - BOUNCE_UP_MS);
                    offsetY = -dropDir * BOUNCE_HEIGHT + dropDir * EXIT_DROP * easeInCubic(t);
                    alpha   = Math.max(0f, 1f - t * 1.5f);
                }
            } else {
                showUntil = -1; showFrom = -1; flashStart = -1;
                return;
            }

        } else if (elapsed < ENTER_DURATION_MS && cfg.animations) {
            float t = easeOutCubic((float) elapsed / ENTER_DURATION_MS);
            scale = 1.15f - 0.15f * t;
            alpha = t;
        }

        int drawWidth  = (int)(baseWidth  * scale);
        int drawHeight = (int)(baseHeight * scale);

        int drawX = switch (cfg.corner) {
            case BOTTOM_RIGHT, TOP_RIGHT -> (int)(baseX + baseWidth  - drawWidth  + offsetX);
            case BOTTOM_LEFT,  TOP_LEFT  -> (int)(baseX + offsetX);
        };
        int drawY = switch (cfg.corner) {
            case BOTTOM_RIGHT, BOTTOM_LEFT -> (int)(baseY + baseHeight - drawHeight + offsetY);
            case TOP_RIGHT,    TOP_LEFT    -> (int)(baseY + offsetY);
        };

        int alphaInt = Math.max(0, Math.min(255, (int)(alpha * 255f)));

        // Frame
        context.method_25294(drawX - 1, drawY - 1,
                drawX + drawWidth + 1, drawY + drawHeight + 1,
                (alphaInt << 24));

        // Image
        context.method_25290(class_10799.field_56883, PREVIEW_ID,
                drawX, drawY, 0f, 0f,
                drawWidth, drawHeight, drawWidth, drawHeight);

        // Overlay
        if (alphaInt < 255) {
            context.method_25294(drawX, drawY, drawX + drawWidth, drawY + drawHeight,
                    ((255 - alphaInt) << 24));
        }

        // ScreenShot animation
        if (cfg.animations && flashStart != -1) {
            long fe = now - flashStart;
            if (fe < FLASH_DURATION_MS) {
                int fa = (int)((1f - (float) fe / FLASH_DURATION_MS) * 255);
                context.method_25294(drawX, drawY, drawX + drawWidth, drawY + drawHeight,
                        (fa << 24) | 0x00FFFFFF);
            } else {
                flashStart = -1;
            }
        }

        // Copy animation
        if (cfg.animations && copyFlashStart != -1) {
            long ce = now - copyFlashStart;
            if (ce < COPY_FLASH_MS) {
                int ca = (int)((1f - (float) ce / COPY_FLASH_MS) * 110);
                context.method_25294(drawX, drawY, drawX + drawWidth, drawY + drawHeight,
                        (ca << 24) | 0x004499FF);
            } else {
                copyFlashStart = -1;
            }
        }

        // Action buttons
        int totalBtnsW = 3 * BTN_W + 2 * BTN_GAP;
        int btnsStartX = drawX + drawWidth - totalBtnsW - 2;
        int btnsY      = drawY + 2;

        double mouseX = mc.field_1729.method_1603() / mc.method_22683().method_4495();
        double mouseY = mc.field_1729.method_1604() / mc.method_22683().method_4495();
        hoveredButton = -1;

        for (int i = 0; i < 3; i++) {
            btnX[i] = btnsStartX + i * (BTN_W + BTN_GAP);
            btnY[i] = btnsY;
            if (mouseX >= btnX[i] && mouseX <= btnX[i] + BTN_W
                    && mouseY >= btnY[i] && mouseY <= btnY[i] + BTN_H) {
                hoveredButton = i;
            }
        }

        class_2960[] icons = {
                hoveredButton == 0 ? ICON_SHOW_H  : ICON_SHOW,
                hoveredButton == 1 ? ICON_COPY_H  : ICON_COPY,
                hoveredButton == 2 ? ICON_CLOSE_H : ICON_CLOSE,
        };
        for (int i = 0; i < 3; i++) {
            context.method_25290(class_10799.field_56883, icons[i],
                    btnX[i], btnY[i], 0f, 0f,
                    BTN_W, BTN_H, BTN_W, BTN_H);
        }
    }

    public static boolean handleClick(double mouseX, double mouseY) {
        if (showFrom == -1) return false;
        if (closeStart != -1) return false;
        if (showUntil != -1 && System.currentTimeMillis() > showUntil) return false;

        for (int i = 0; i < 3; i++) {
            if (btnX[i] == 0 && btnY[i] == 0) continue;
            if (mouseX >= btnX[i] && mouseX <= btnX[i] + BTN_W
                    && mouseY >= btnY[i] && mouseY <= btnY[i] + BTN_H) {
                switch (i) {
                    case 0 -> openFullscreen();
                    case 1 -> copyToClipboard();
                    case 2 -> close();
                }
                return true;
            }
        }
        return false;
    }

    private static void copyToClipboard() {
        if (previewTexture == null || previewTexture.method_4525() == null) return;
        try {
            class_1011 img = previewTexture.method_4525();
            java.io.File tmp = java.io.File.createTempFile("better_screenshots_", ".png");
            tmp.deleteOnExit();
            img.method_4314(tmp.toPath());
            copyPathToClipboard(tmp.getAbsolutePath());
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static void copyPathToClipboard(String path) {
        try {
            String os = System.getProperty("os.name").toLowerCase();

            if (os.contains("mac")) {
                Runtime.getRuntime().exec(new String[]{
                        "osascript", "-e",
                        "set the clipboard to (read (POSIX file \""
                                + path + "\") as «class PNGf»)"
                });
            } else if (os.contains("win")) {
                Runtime.getRuntime().exec(new String[]{"powershell", "-command",
                        "Add-Type -Assembly 'System.Windows.Forms';" +
                                "Add-Type -Assembly 'System.Drawing';" +
                                "[System.Windows.Forms.Clipboard]::SetImage(" +
                                "[System.Drawing.Image]::FromFile('" +
                                path.replace("'", "''") + "'))"});
            } else {
                try {
                    Runtime.getRuntime().exec(new String[]{
                            "xclip", "-selection", "clipboard",
                            "-t", "image/png", "-i", path}).waitFor();
                } catch (Exception e) {
                    Runtime.getRuntime().exec(new String[]{
                            "xsel", "--clipboard", "--input", path});
                }
            }
            copyFlashStart = System.currentTimeMillis();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void openFullscreen() {
        class_310 mc = class_310.method_1551();
        if (previewTexture != null) {
            mc.execute(() -> {
                ScreenshotFullscreenScreen screen =
                        new ScreenshotFullscreenScreen(mc.field_1755);
                screen.useCurrentTexture();
                screen.setFromHud(true);
                captureBackground(() -> mc.method_1507(screen));
            });
        }
    }
}