package dev.gdlev.better_screenshots.client;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;
import org.jspecify.annotations.NonNull;

public class ScreenshotConfigScreen extends class_437 {

    private final class_437 parent;

    private static final int COL_W = 180;
    private static final int BTN_H = 20;
    private static final int GAP   = 26;
    private static final int SEP   = 20;

    private final List<class_2960>     thumbIds      = new ArrayList<>();
    private final List<class_1043> thumbTextures = new ArrayList<>();
    private final List<File>           thumbFiles    = new ArrayList<>();
    private int screenshotCount = 0;

    private static final class_2960 ICON_SHOW    = class_2960.method_60655("better_screenshots", "textures/gui/show.png");
    private static final class_2960 ICON_SHOW_H  = class_2960.method_60655("better_screenshots", "textures/gui/show_hover.png");
    private static final class_2960 ICON_COPY    = class_2960.method_60655("better_screenshots", "textures/gui/copy.png");
    private static final class_2960 ICON_COPY_H  = class_2960.method_60655("better_screenshots", "textures/gui/copy_hover.png");
    private static final class_2960 ICON_DELETE  = class_2960.method_60655("better_screenshots", "textures/gui/close.png");
    private static final class_2960 ICON_DELETE_H= class_2960.method_60655("better_screenshots", "textures/gui/close_hover.png");

    private static final int ACT_BTN_W   = 8;
    private static final int ACT_BTN_H   = 10;
    private static final int ACT_BTN_GAP = 0;

    private int selectedThumbIdx = -1;

    private final int[] actionBtnX = new int[3];
    private final int[] actionBtnY = new int[3];

    public ScreenshotConfigScreen(class_437 parent) {
        super(class_2561.method_43471("better_screenshots.title"));
        this.parent = parent;
    }

    private int thumbW()     { return (COL_W - 6) / 2; }
    private int thumbH()     { return (int)(thumbW() * 9f / 16f); }
    private int thumbsH()    { return thumbH() * 2 + 4; }
    private int panelH()     { return 28 + Math.max(GAP * 4 + BTN_H * 4 + 4, 14 + thumbsH() + 6 + BTN_H) + 24; }
    private int panelY()     { return (this.field_22790 - panelH()) / 2; }
    private int panelX()     { return this.field_22789 / 2 - COL_W - SEP / 2 - 12; }
    private int panelW()     { return COL_W * 2 + SEP + 24; }
    private int leftX()      { return panelX() + 12; }
    private int rightX()     { return leftX() + COL_W + SEP; }
    private int topY()       { return panelY() + 28; }
    private int bottomBtnY() { return panelY() + panelH() - 12 - BTN_H; }

    @Override
    protected void method_25426() {
        if (thumbFiles.isEmpty()) {
            loadThumbnails();
        }

        int lx = leftX();
        int rx = rightX();
        int ty = topY();
        int by = bottomBtnY();

        // Settings

        method_37063(class_5676.method_32606(
                        (ScreenshotConfig.Corner c) -> class_2561.method_43471(switch (c) {
                            case BOTTOM_RIGHT -> "better_screenshots.config.corner.bottom_right";
                            case BOTTOM_LEFT  -> "better_screenshots.config.corner.bottom_left";
                            case TOP_RIGHT    -> "better_screenshots.config.corner.top_right";
                            case TOP_LEFT     -> "better_screenshots.config.corner.top_left";
                        }),
                        ScreenshotConfig.get().corner)
                .method_32624(ScreenshotConfig.Corner.values())
                .method_32617(lx, ty + 14, COL_W, BTN_H,
                        class_2561.method_43471("better_screenshots.config.corner"),
                        (btn, val) -> { ScreenshotConfig.get().corner = val; ScreenshotConfig.save(); }));

        method_37063(class_5676.method_32606(
                        (Boolean val) -> class_2561.method_43471(val
                                ? "better_screenshots.config.animations.on"
                                : "better_screenshots.config.animations.off"),
                        ScreenshotConfig.get().animations)
                .method_32624(Boolean.TRUE, Boolean.FALSE)
                .method_32617(lx, ty + 14 + GAP, COL_W, BTN_H,
                        class_2561.method_43471("better_screenshots.config.animations"),
                        (btn, val) -> { ScreenshotConfig.get().animations = val; ScreenshotConfig.save(); }));

        method_37063(class_5676.method_32606(
                        (ScreenshotConfig.ShutterSound s) -> class_2561.method_43471(switch (s) {
                            case NONE    -> "better_screenshots.config.sound.none";
                            case SOFT    -> "better_screenshots.config.sound.soft";
                            case CLASSIC -> "better_screenshots.config.sound.classic";
                        }),
                        ScreenshotConfig.get().shutterSound)
                .method_32624(ScreenshotConfig.ShutterSound.values())
                .method_32617(lx, ty + 14 + GAP * 2, COL_W, BTN_H,
                        class_2561.method_43471("better_screenshots.config.sound"),
                        (btn, val) -> { ScreenshotConfig.get().shutterSound = val; ScreenshotConfig.save(); }));

        // Preview time Slider
        double initialDuration = (ScreenshotConfig.get().previewDurationSeconds - 1.0) / 14.0;
        method_37063(new DurationSlider(
                lx, ty + 14 + GAP * 3, COL_W, BTN_H, initialDuration));

        // Back
        method_37063(class_4185.method_46430(
                        class_2561.method_43471("better_screenshots.config.done"),
                        btn -> field_22787.method_1507(parent))
                .method_46434(lx, by, COL_W, BTN_H)
                .method_46431());

        // Gallery
        method_37063(class_4185.method_46430(
                        class_2561.method_43471("better_screenshots.config.open_gallery"),
                        btn -> field_22787.method_1507(new ScreenshotGalleryScreen(this)))
                .method_46434(rx, by, COL_W, BTN_H)
                .method_46431());
    }

    @Override
    public void method_25394(@NonNull class_332 context, int mouseX, int mouseY, float delta) {
        int tw = thumbW();
        int th = thumbH();
        int px = panelX();
        int py = panelY();
        int pw = panelW();
        int ph = panelH();
        int lx = leftX();
        int rx = rightX();
        int ty = topY();
        int by = bottomBtnY();

        drawPanel(context, px, py, pw, ph);

        context.method_27534(field_22793,
                class_2561.method_43470("✦  ").method_10852(class_2561.method_43471("better_screenshots.title")).method_27693("  ✦"),
                this.field_22789 / 2, py + 8, 0xFFCCCCCC);

        context.method_25294(px + 8, py + 20, px + pw - 8, py + 21, 0xFF444444);

        int sepX = lx + COL_W + SEP / 2;
        context.method_25294(sepX, py + 22, sepX + 1, py + ph - 4, 0xFF333333);

        context.method_27534(field_22793,
                class_2561.method_43471("better_screenshots.config.section.settings"),
                lx + COL_W / 2, ty + 2, 0xFF777777);
        context.method_27534(field_22793,
                class_2561.method_43471("better_screenshots.config.section.screenshots"),
                rx + COL_W / 2, ty + 2, 0xFF777777);

        int thumbsTopY = ty + 14;

        // Action buttons reset
        Arrays.fill(actionBtnX, -100);
        Arrays.fill(actionBtnY, -100);

        for (int i = 0; i < 4; i++) {
            int col = i % 2;
            int row = i / 2;
            int tx  = rx + col * (tw + 6);
            int tty = thumbsTopY + row * (th + 4);

            boolean hov = i < thumbFiles.size() && thumbFiles.get(i) != null
                    && mouseX >= tx && mouseX <= tx + tw
                    && mouseY >= tty && mouseY <= tty + th;
            boolean sel = (i == selectedThumbIdx);
            int border  = sel ? 0xFFFFFFFF : hov ? 0xFFAAAAAA : 0xFF444444;
            context.method_25294(tx - 1, tty - 1, tx + tw + 1, tty + th + 1, border);

            if (i < thumbTextures.size() && thumbTextures.get(i) != null) {
                context.method_25290(class_10799.field_56883, thumbIds.get(i),
                        tx, tty, 0f, 0f, tw, th, tw, th);
            } else if (i < thumbIds.size()) {
                context.method_25294(tx, tty, tx + tw, tty + th, 0xFF1a1a1a);
                context.method_27534(field_22793,
                        class_2561.method_43471("better_screenshots.gallery.loading"),
                        tx + tw / 2, tty + th / 2 - 4, 0xFF555555);
            } else {
                context.method_25294(tx, tty, tx + tw, tty + th, 0xFF161616);
            }

            // Nametag on hover
            if (hov) {
                context.method_44379(tx, tty, tx + tw, tty + th);
                String name = thumbFiles.get(i).getName().replace(".png", "");
                int nameW   = field_22793.method_1727(name);
                int labelH  = 12;
                int labelY  = tty + th - labelH;
                context.method_25294(tx, labelY, tx + tw, tty + th, 0xCC000000);
                if (nameW <= tw - 4) {
                    context.method_27534(field_22793,
                            class_2561.method_43470(name), tx + tw / 2, labelY + 2, 0xFFFFFFFF);
                } else {
                    String clipped = name;
                    while (field_22793.method_1727(clipped + "…") > tw - 4 && !clipped.isEmpty())
                        clipped = clipped.substring(0, clipped.length() - 1);
                    context.method_27534(field_22793,
                            class_2561.method_43470(clipped + "…"), tx + tw / 2, labelY + 2, 0xFFFFFFFF);
                }
                context.method_44380();
            }

            // Copy animation
            if (sel) {
                int ca = ScreenshotPreviewRenderer.getCopyFlashAlpha();
                if (ca > 0) context.method_25294(tx, tty, tx + tw, tty + th, (ca << 24) | 0x004499FF);
            }

            // Action buttons
            if (sel && i < thumbFiles.size() && thumbFiles.get(i) != null) {
                int totalBtnsW = 3 * ACT_BTN_W + 2 * ACT_BTN_GAP;
                int btnsStartX = tx + tw - totalBtnsW - 2;
                int btnsY      = tty + 2;

                class_2960[] icons  = { ICON_SHOW,   ICON_COPY,   ICON_DELETE   };
                class_2960[] iconsH = { ICON_SHOW_H, ICON_COPY_H, ICON_DELETE_H };

                for (int b = 0; b < 3; b++) {
                    actionBtnX[b] = btnsStartX + b * (ACT_BTN_W + ACT_BTN_GAP);
                    actionBtnY[b] = btnsY;

                    boolean btnHov = mouseX >= actionBtnX[b]
                            && mouseX <= actionBtnX[b] + ACT_BTN_W
                            && mouseY >= actionBtnY[b]
                            && mouseY <= actionBtnY[b] + ACT_BTN_H;

                    context.method_25290(
                            class_10799.field_56883,
                            btnHov ? iconsH[b] : icons[b],
                            actionBtnX[b], actionBtnY[b],
                            0f, 0f, ACT_BTN_W, ACT_BTN_H, ACT_BTN_W, ACT_BTN_H);
                }
            }
        }

        class_2561 countText = screenshotCount == 0
                ? class_2561.method_43471("better_screenshots.gallery.no_screenshots")
                : screenshotCount == 1
                ? class_2561.method_43471("better_screenshots.gallery.count.one")
                : class_2561.method_43469("better_screenshots.gallery.count.many",
                String.valueOf(screenshotCount));
        context.method_27534(field_22793,
                countText, rx + COL_W / 2, by - 10, 0xFF666666);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    public boolean handleClick(int button, double mouseX, double mouseY) {
        if (button != 0) return false;

        // Show action buttons when selected
        if (selectedThumbIdx >= 0) {
            for (int i = 0; i < 3; i++) {
                if (mouseX >= actionBtnX[i] && mouseX <= actionBtnX[i] + ACT_BTN_W
                        && mouseY >= actionBtnY[i] && mouseY <= actionBtnY[i] + ACT_BTN_H) {
                    switch (i) {
                        case 0 -> openFullscreen(selectedThumbIdx);
                        case 1 -> copyFile(selectedThumbIdx);
                        case 2 -> deleteFile(selectedThumbIdx);
                    }
                    return true;
                }
            }
        }

        int tw = thumbW();
        int th = thumbH();
        int rx = rightX();
        int thumbsTopY = topY() + 14;

        for (int i = 0; i < Math.min(4, thumbFiles.size()); i++) {
            int col = i % 2;
            int row = i / 2;
            int tx  = rx + col * (tw + 6);
            int tty = thumbsTopY + row * (th + 4);

            if (mouseX >= tx && mouseX <= tx + tw
                    && mouseY >= tty && mouseY <= tty + th) {
                selectedThumbIdx = (selectedThumbIdx == i) ? -1 : i;
                return true;
            }
        }
        return false;
    }

    // Actions

    private void openFullscreen(int idx) {
        if (idx < 0 || idx >= thumbFiles.size()) return;
        class_310 mc = class_310.method_1551();
        ScreenshotFullscreenScreen screen = new ScreenshotFullscreenScreen(this);
        ScreenshotPreviewRenderer.captureBackground(() -> mc.method_1507(screen));

        Thread.ofVirtual().start(() -> {
            try {
                byte[] bytes = Files.readAllBytes(thumbFiles.get(idx).toPath());
                class_1011 img = class_1011.method_4309(new java.io.ByteArrayInputStream(bytes));
                mc.execute(() -> {
                    ScreenshotPreviewRenderer.setFullscreenTexture(img);
                    screen.markLoaded();
                });
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void copyFile(int idx) {
        if (idx < 0 || idx >= thumbFiles.size()) return;
        ScreenshotPreviewRenderer.copyFileToClipboard(thumbFiles.get(idx));
    }

    private void deleteFile(int idx) {
        if (idx < 0 || idx >= thumbFiles.size()) return;
        File file = thumbFiles.get(idx);
        if (file.delete()) {
            screenshotCount = Math.max(0, screenshotCount - 1);
            selectedThumbIdx = -1;
            loadThumbnails();
        }
    }

    // thumbnail loading

    private void loadThumbnails() {
        for (class_1043 t : thumbTextures) if (t != null) t.close();
        thumbTextures.clear();
        thumbIds.clear();
        thumbFiles.clear();
        screenshotCount = 0;
        selectedThumbIdx = -1;

        File dir = new File(class_310.method_1551().field_1697, "screenshots");
        if (!dir.exists()) return;

        File[] files = dir.listFiles(
                f -> f.isFile() && f.getName().toLowerCase().endsWith(".png"));
        if (files == null || files.length == 0) return;

        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        screenshotCount = files.length;

        int count = Math.min(files.length, 4);
        for (int i = 0; i < count; i++) {
            thumbIds.add(class_2960.method_60655("better_screenshots",
                    "cfg_thumb_" + i + "_" + files[i].lastModified()));
            thumbTextures.add(null);
            thumbFiles.add(files[i]);
        }

        class_310 mc = class_310.method_1551();
        for (int i = 0; i < count; i++) {
            final int  idx  = i;
            final File file = files[i];
            Thread.ofVirtual().start(() -> {
                try (InputStream is = Files.newInputStream(file.toPath())) {
                    class_1011 img   = class_1011.method_4309(is);
                    class_1011 thumb = scaleTo(img, thumbW(), thumbH());
                    img.close();
                    mc.execute(() -> {
                        if (idx >= thumbTextures.size()) return;
                        class_1043 tex =
                                new class_1043(() -> "cfg_thumb_" + idx, thumb);
                        mc.method_1531().method_4616(thumbIds.get(idx), tex);
                        thumbTextures.set(idx, tex);
                    });
                } catch (Exception ignored) {}
            });
        }
    }

    private class_1011 scaleTo(class_1011 src, int tw, int th) {
        float scale = Math.min((float) tw / src.method_4307(),
                (float) th / src.method_4323());
        int sw = (int)(src.method_4307()  * scale);
        int sh = (int)(src.method_4323() * scale);
        int ox = (tw - sw) / 2;
        int oy = (th - sh) / 2;

        class_1011 dst = new class_1011(tw, th, false);
        for (int y = 0; y < th; y++)
            for (int x = 0; x < tw; x++)
                dst.method_4305(x, y, 0xFF000000);
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                int sx   = Math.min((int)((float) x / sw * src.method_4307()),  src.method_4307()  - 1);
                int sy   = Math.min((int)((float) y / sh * src.method_4323()), src.method_4323() - 1);
                int argb = src.method_61940(sx, sy);
                int a    = (argb >> 24) & 0xFF;
                int r    = (argb >> 16) & 0xFF;
                int g    = (argb >>  8) & 0xFF;
                int b    =  argb        & 0xFF;
                dst.method_4305(ox + x, oy + y, (a << 24) | (b << 16) | (g << 8) | r);
            }
        }
        return dst;
    }

    private void drawPanel(class_332 ctx, int x, int y, int w, int h) {
        ctx.method_25294(x,         y,         x + w,     y + h,     0xAA000000);
        ctx.method_25294(x,         y,         x + w,     y + 1,     0xFF555555);
        ctx.method_25294(x,         y + h - 1, x + w,     y + h,     0xFF555555);
        ctx.method_25294(x,         y,         x + 1,     y + h,     0xFF555555);
        ctx.method_25294(x + w - 1, y,         x + w,     y + h,     0xFF555555);
    }

    @Override
    public void method_25419() {
        for (class_1043 t : thumbTextures) if (t != null) t.close();
        field_22787.method_1507(parent);
    }
}