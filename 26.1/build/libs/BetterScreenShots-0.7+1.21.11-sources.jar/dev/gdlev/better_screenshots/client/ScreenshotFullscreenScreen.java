package dev.gdlev.better_screenshots.client;

import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jspecify.annotations.NonNull;

public class ScreenshotFullscreenScreen extends class_437 {

    private final class_437 parent;

    private static final long  ENTER_DURATION_MS = 350;
    private static final long  EXIT_DURATION_MS  = 500;
    private static final long  BOUNCE_UP_MS      = 120;
    private static final long  BLUR_FADE_MS      = 180;
    private static final float BOUNCE_HEIGHT     = 18f;
    private static final float EXIT_DROP         = 300f;
    private static final int   MARGIN            = 32;

    private long    openedAt     = -1;
    private long    loadingStart = System.currentTimeMillis();
    private long    closeStart   = -1;
    private boolean loaded       = false;
    private boolean closing      = false;

    private int startX, startY, startW, startH;
    private class_1043 expectedTexture = null;
    private boolean fromHud = false;
    private boolean useFullscreenTex = false;

    private int lastCurX, lastCurY, lastCurW, lastCurH;

    public ScreenshotFullscreenScreen(class_437 parent) {
        super(class_2561.method_43470(""));
        this.parent = parent;
    }

    public void markLoaded() {
        loaded             = true;
        useFullscreenTex   = true;
        expectedTexture    = ScreenshotPreviewRenderer.getFullscreenTexture();
    }

    public void useCurrentTexture() {
        loaded          = true;
        expectedTexture = ScreenshotPreviewRenderer.getPreviewTexture();
    }

    @Override
    protected void method_25426() {
        loadingStart = System.currentTimeMillis();
        openedAt     = -1;
        closing      = false;
        closeStart   = -1;
        if (loaded && expectedTexture != null) initStartPosition();
    }

    public void setFromHud(boolean value) { this.fromHud = value; }

    private class_2960 getTexId() {
        return useFullscreenTex
                ? ScreenshotPreviewRenderer.FULLSCREEN_ID
                : ScreenshotPreviewRenderer.PREVIEW_ID;
    }

    private void initStartPosition() {
        var img = expectedTexture;
        if (img == null || img.method_4525() == null) return;

        int targetW = this.field_22789  - MARGIN * 2;
        int targetH = this.field_22790 - MARGIN * 2;

        float scale = Math.min(
                (float) targetW / img.method_4525().method_4307(),
                (float) targetH / img.method_4525().method_4323());
        targetW = (int)(img.method_4525().method_4307()  * scale);
        targetH = (int)(img.method_4525().method_4323() * scale);

        if (fromHud) {
            ScreenshotConfig cfg = ScreenshotConfig.get();
            int previewW = this.field_22789 / 4;
            int previewH = (previewW * img.method_4525().method_4323()) / img.method_4525().method_4307();
            int m = 10;
            startX = switch (cfg.corner) {
                case BOTTOM_RIGHT, TOP_RIGHT -> this.field_22789  - previewW - m;
                case BOTTOM_LEFT,  TOP_LEFT  -> m;
            };
            startY = switch (cfg.corner) {
                case BOTTOM_RIGHT, BOTTOM_LEFT -> this.field_22790 - previewH - m;
                case TOP_RIGHT,    TOP_LEFT    -> m;
            };
            startW = previewW;
            startH = previewH;
        } else {
            startX = (this.field_22789  - targetW) / 2;
            startY = this.field_22790;
            startW = targetW;
            startH = targetH;
        }
    }

    private float easeOutCubic(float t) { return 1f - (float) Math.pow(1f - t, 3); }
    private float easeInCubic(float t)  { return t * t * t; }

    private void startClose() {
        if (closing) return;
        closing    = true;
        closeStart = System.currentTimeMillis();
    }

    @Override
    public void method_25420(@NonNull class_332 context, int mouseX, int mouseY, float delta) {
        if (parent != null) {
            parent.method_25420(context, mouseX, mouseY, delta);
            parent.method_25394(context, mouseX, mouseY, delta);
        } else {
            super.method_25420(context, mouseX, mouseY, delta);
        }
    }

    @Override
    public void method_25394(@NonNull class_332 context, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        boolean useAnim = ScreenshotConfig.get().animations;

        // Drawing BG
        int bgAlpha;
        if (closing && closeStart >= 0) {
            long exitElapsed = now - closeStart;
            long totalMs     = EXIT_DURATION_MS + BLUR_FADE_MS;
            if (!useAnim || exitElapsed > totalMs) {
                this.field_22787.method_1507(parent);
                return;
            }
            float totalT  = Math.min((float) exitElapsed / totalMs, 1f);
            bgAlpha = (int)(Math.max(0f, 0.8f * (1f - totalT)) * 255);
        } else {
            float bgProgress = useAnim ? Math.min((float)(now - loadingStart) / ENTER_DURATION_MS, 1.0f) : 1.0f;
            bgAlpha = (int)(0.8f * bgProgress * 255);
        }

        context.method_25294(0, 0, this.field_22789, this.field_22790, (bgAlpha << 24));

        // Preview loader
        if (!loaded || expectedTexture == null || expectedTexture.method_4525() == null) {
            drawLoadingSpinner(context);
            return;
        }

        // Animation start seq
        if (openedAt < 0) {
            initStartPosition();
            openedAt = now;
        }

        // Calculating target dimensions
        var   img   = expectedTexture;
        int   tW    = this.field_22789  - MARGIN * 2;
        int   tH    = this.field_22790 - MARGIN * 2;
        float sc    = Math.min(
                (float) tW / img.method_4525().method_4307(),
                (float) tH / img.method_4525().method_4323());
        int targetW = (int)(img.method_4525().method_4307()  * sc);
        int targetH = (int)(img.method_4525().method_4323() * sc);
        int targetX = (this.field_22789  - targetW) / 2;
        int targetY = (this.field_22790 - targetH) / 2;

        // Hiding Animation seq
        if (closing && closeStart >= 0) {
            long exitElapsed = now - closeStart;
            if (exitElapsed <= EXIT_DURATION_MS) {
                float overallT    = (float) exitElapsed / EXIT_DURATION_MS;
                float imgAlpha    = Math.max(0f, 1f - overallT * 1.4f);
                int   imgAlphaInt = (int)(imgAlpha * 255);

                float offsetY;
                if (exitElapsed < BOUNCE_UP_MS) {
                    offsetY = -BOUNCE_HEIGHT * easeOutCubic((float) exitElapsed / BOUNCE_UP_MS);
                } else {
                    float tDrop = (float)(exitElapsed - BOUNCE_UP_MS) / (EXIT_DURATION_MS - BOUNCE_UP_MS);
                    offsetY = -BOUNCE_HEIGHT + EXIT_DROP * easeInCubic(tDrop);
                }

                int imgY = (int)(lastCurY + offsetY);
                context.method_25290(class_10799.field_56883, getTexId(),
                        lastCurX, imgY, 0f, 0f, lastCurW, lastCurH, lastCurW, lastCurH);

                if (imgAlphaInt < 255) {
                    context.method_25294(lastCurX, imgY, lastCurX + lastCurW, imgY + lastCurH,
                            ((255 - imgAlphaInt) << 24));
                }
            }
            return;
        }

        // Entrance Animation seq
        float rawProgress = useAnim
                ? Math.min((float)(now - openedAt) / ENTER_DURATION_MS, 1.0f)
                : 1.0f;
        float t = easeOutCubic(rawProgress);

        int curX = (int)(startX + (targetX - startX) * t);
        int curY = (int)(startY + (targetY - startY) * t);
        int curW = (int)(startW + (targetW - startW) * t);
        int curH = (int)(startH + (targetH - startH) * t);

        lastCurX = targetX;
        lastCurY = targetY;
        lastCurW = targetW;
        lastCurH = targetH;

        context.method_25290(class_10799.field_56883, getTexId(),
                curX, curY, 0f, 0f, curW, curH, curW, curH);

        if (rawProgress >= 1.0f) {
            context.method_27534(field_22793,
                    class_2561.method_43471("better_screenshots.fullscreen.hint"),
                    this.field_22789 / 2, this.field_22790 - 16, 0x66FFFFFF);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawLoadingSpinner(class_332 context) {
        long  now     = System.currentTimeMillis();
        float elapsed = (now - loadingStart) / 1000f;
        int   cx      = this.field_22789  / 2;
        int   cy      = this.field_22790 / 2;
        int   radius  = 16;
        int   dots    = 8;

        for (int i = 0; i < dots; i++) {
            float angle  = (float)(i * Math.PI * 2 / dots) - elapsed * 3f;
            float bright = ((i + (int)(elapsed * dots)) % dots) / (float) dots;
            int   alpha  = (int)(60 + bright * 195);
            int   size   = (int)(1 + bright * 2);
            int   dx     = (int)(Math.cos(angle) * radius);
            int   dy     = (int)(Math.sin(angle) * radius);
            context.method_25294(cx + dx - size, cy + dy - size,
                    cx + dx + size, cy + dy + size,
                    (alpha << 24) | 0x00FFFFFF);
        }

        context.method_27534(field_22793,
                class_2561.method_43471("better_screenshots.fullscreen.loading"),
                cx, cy + radius + 8, 0x88FFFFFF);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {}

    @Override
    public boolean method_25404(net.minecraft.class_11908 input) {
        if (input.comp_4795() == 256) {
            if (!loaded || expectedTexture == null || expectedTexture.method_4525() == null) {
                this.field_22787.method_1507(parent);
            } else {
                if (!ScreenshotConfig.get().animations) {
                    this.field_22787.method_1507(parent);
                } else {
                    startClose();
                }
            }
            return true;
        }
        return super.method_25404(input);
    }
}