package dev.gdlev.better_screenshots.client;

import net.minecraft.class_2561;
import net.minecraft.class_357;

public class DurationSlider extends class_357 {

    public DurationSlider(int x, int y, int width, int height, double initialValue) {
        super(x, y, width, height, class_2561.method_43470(""), initialValue);
        method_25346();
    }

    private int toSeconds() {
        return 1 + (int) Math.round(field_22753 * 14.0);
    }

    @Override
    protected void method_25346() {
        method_25355(class_2561.method_43469("better_screenshots.config.preview_duration",
                toSeconds()));
    }

    @Override
    protected void method_25344() {
        ScreenshotConfig.get().previewDurationSeconds = toSeconds();
        ScreenshotConfig.save();
    }
}